# esptool.py test suite

See the [Automated Integration Tests section in `esptool.py` documentation](https://docs.espressif.com/projects/esptool/en/latest/esp32/contributing.html#automated-integration-tests) to learn about the test suite and how to run it.
